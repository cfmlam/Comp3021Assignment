import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;

public class Game {
	
	public static boolean isInteger(String s, int radix) {		//Function to determine whether a string is number or not
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
	
	public Map initialize(File inputFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(inputFile));
		// Read the first of the input file
		String line = br.readLine();
		int M = Integer.parseInt(line.split(" ")[0]);
		//int N = Integer.parseInt(line.split(" ")[1]);
		
		// To do: define a map
		Map CurMap= new Map();  //Define CurMap as the new map
		// Read the following M lines of the Map
		for (int i = 0; i < M; i++) {
			line = br.readLine();
			char[] mapChar = line.toCharArray();	//Separate the string into char array
			int mark=0;					// act as column marker
			for(char a:mapChar)			// read each letter in char array
			{
				Position Temp = new Position();		//initialize a position temp variable
				switch(a)							// set the properties of position
				{
					case('#'):
						Temp.setPosition(i, mark, "Wall");
						break;
					case(' '):
						Temp.setPosition(i, mark, "Road");
						break;
					case('P'):
						Temp.setPosition(i, mark, "Pokemon");
						break;
					case('S'):
						Temp.setPosition(i, mark, "Station");
						break;
					case('B'):
						Temp.setPosition(i, mark, "Begin");
						CurMap.setStart(i, mark);
						break;
					case('D'):
						Temp.setPosition(i, mark, "End");
						CurMap.setEnd(i, mark);
						break;
				}
				CurMap.setMap(Temp);		//add to the arraylist in map
				mark++;
			}
			// to do
			// Read the map line by line
		}
		
		// to do
		// Find the number of stations and pokemons in the map 
		// Continue read the information of all the stations and pokemons by using br.readLine();
		
		line=br.readLine();		//read information of station and pokemon 
		String[] StringArray = line.split(", ");
		StringArray[0] = StringArray[0].substring(1, 5);
		String[] PosiArray = StringArray[0].split(",");
		if(isInteger(line,8))	//Station information if true
		{
			Station thisStat = new Station(Integer.parseInt(StringArray[1]));
			thisStat.setPosition(Integer.parseInt(PosiArray[0]), Integer.parseInt(PosiArray[1]));
			CurMap.setStation(thisStat);
		}
		else					//Pokemon information if false
		{
			Pokemon thisPoke = new Pokemon(StringArray[1],StringArray[2],Integer.parseInt(StringArray[3]),Integer.parseInt(StringArray[4]));
			thisPoke.setPosition(Integer.parseInt(PosiArray[0]), Integer.parseInt(PosiArray[1]));
			CurMap.setPoke(thisPoke);
		}
		
		br.close();
		return CurMap;
	}
	
	
	public static void main(String[] args) throws Exception{
		File inputFile = new File("./sampleIn.txt");
		File outputFile = new File("./sampleOut.txt");
		//System.out.println("hi");
		if (args.length > 0) {
			inputFile = new File(args[0]);
		} 

		if (args.length > 1) {
			outputFile = new File(args[1]);
		}
		//System.out.println("hi");
		Game game = new Game();
		Map map = new Map();
		//System.out.println("hi");
		map = game.initialize(inputFile);
		Player player = new Player(map.getStart());
		ArrayList<Position> path = new ArrayList<Position>();
		path = map.ValidPath();
		for(int i=0; i<path.size(); i++)
		{
			//System.out.println(path.get(i).getX() + ":" + path.get(i).getY() + ":" + path.get(i).getType());
			player.addPath(path.get(i));
		}
		ArrayList<Integer> resultArray = new ArrayList<Integer>();
		resultArray = map.CalcScore(path, player);
		
		try{
		BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
		bw.write(resultArray.get(0));
		bw.newLine();
		bw.write(resultArray.get(1) + ":" + resultArray.get(2) + ":" + resultArray.get(3) + ":" + resultArray.get(4));
		bw.newLine();
		for(int i=0; i<path.size(); i++)
		{
			bw.write("<" + path.get(i).getX() + "," + path.get(i).getY() + ">");
			if(path.get(i+1)!=null)
			bw.write("->");
		}
		bw.close();
		
		}catch (Exception e)
		{
			System.out.println("Error occurs in writing files: " + e);
		}
		
		// TO DO 
		// Read the configures of the map and pokemons from the file inputFile
		// and output the results to the file outputFile
		
		System.out.println("End");
	}
	
	
}

