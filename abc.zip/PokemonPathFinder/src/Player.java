import java.util.ArrayList;

public class Player extends Position{
	private Position current;
	private ArrayList<Pokemon> caught = new ArrayList<Pokemon>();
	private int pokeball;
	private ArrayList<Position> path = new ArrayList<Position>();
	
	Player(Position xy)
	{
		super(xy);
		pokeball=0;
	}
	
	public Position getcurr()	//return the position of player
	{
		return current;
	}
	
	public int getCaughtSize()		//return the number of pokemon owned
	{
		return caught.size();
	}
	
	public int PokeType()	//return the number of types that player owned
	{
		int type=0;
		ArrayList<String> typeArray = new ArrayList<String>();
		for(int i=0; i<caught.size(); i++)
		{
			if(!typeArray.contains(caught.get(i).getType()))	//check if the type is existed or not
			{
				typeArray.add(caught.get(i).getType());
				type++;
			}
		}
		
		return type;
	}
	
	public int getMaxCP()	//return the Maximum Combat Power
	{
		int CP=0;
		for(int i=0; i< caught.size(); i++)
		{
			if(caught.get(i).getPower()>CP)
			CP = caught.get(i).getPower();
		}
		
		return CP;
	}
	
	public void addCaught(Pokemon o)
	{
		caught.add(o);
	}
	
	public int getpoke()
	{
		return pokeball;
	}
	
	public void setCurr(Position q)
	{
		current=q;
	}
	
	public void addPath(Position o)
	{
		path.add(o);
	}
	
	public void setpoke(int o)
	{
		pokeball=o;
	}
}
