import java.util.ArrayList;

public class Map{
	private ArrayList<Position> mapArray = new ArrayList<Position>();
	private ArrayList<Pokemon> PokeArray = new ArrayList<Pokemon>();
	private ArrayList<Station> StationArray = new ArrayList<Station>();
	private Position Start;
	private Position End;
	private ArrayList<Position> PathArray= new ArrayList<Position>();
	private ArrayList<Position> InvalidArray = new ArrayList<Position>();
	
	public void setMap(int row, int column, String type)
	{
		Position cell = new Position(row, column, type);
		mapArray.add(cell);
	}
	
	public Position getStart() //return the start position
	{
		return Start;
	}
	
	public boolean pathFinder(int x, int y)
	{
		Position q = new Position(x,y);
		if(mapArray.contains(q)!=true) 
			return false;
		if(q==End)
			return true;
		else
		{
			//System.out.println(mapArray.get(mapArray.indexOf(q)).getType());
			if(mapArray.get(mapArray.indexOf(q)).getType().equals("Wall")) 
			return false;
			if(PathArray.contains(q))
				return false;
		}
		
		PathArray.add(mapArray.get(mapArray.indexOf(q)));
		if(pathFinder(x, y-1) == true) return true;
		if(pathFinder(x-1, y) == true) return true;
		if(pathFinder(x+1, y) == true) return true;
		if(pathFinder(x, y+1) == true) return true;
		InvalidArray.add(mapArray.get(mapArray.indexOf(q)));
		
		
		
		return false;
	}
	
	public ArrayList<Position> ValidPath() 
	{
		this.pathFinder(this.Start.getX(), this.Start.getY());
		
		System.out.println("PathArray:");
		for(int i=0; i< PathArray.size(); i++)
			System.out.println(PathArray.get(i).getX() + ":" + PathArray.get(i).getY());
		System.out.println("InvalidArray");
		for(int i=0; i< InvalidArray.size(); i++)
			System.out.println(InvalidArray.get(i).getX() + ":" + InvalidArray.get(i).getY());
		//System.out.println("PathArray: " + PathArray.size() +", InvalidArray: " + InvalidArray.size());
		//PathArray.removeAll(InvalidArray);
		//System.out.println("PathArray:");
		
		
		return PathArray;
	}
	
	public ArrayList<Integer> CalcScore(ArrayList<Position> o, Player p)
	{
		ArrayList<Integer> resultArray = new ArrayList<Integer>();
		int score=0;
		for(int i=0 ; i<o.size() ; i++)		//use for loop to scan through the valid path
		{
			p.setCurr(o.get(i));
			if(StationArray.contains(o.get(i)))		//check if the path consist of station
			{
				int pokeball=0;
				pokeball = StationArray.get(StationArray.indexOf(o.get(i))).getBallCount();
				p.setpoke(pokeball);
			}
			
			if(PokeArray.contains(o.get(i)))	//check if the path consist of pokemon
			{
				Pokemon monster = PokeArray.get(PokeArray.indexOf(o.get(i))).getPokeInfo();
				if(p.getpoke()>monster.getball())
				{
					p.addCaught(monster);
					p.setpoke(p.getpoke()-monster.getball());
				}
			}
			score--;		//steps is minus score
		}
		
		score+=p.getMaxCP()+p.getpoke()+5*p.getCaughtSize()+10*p.PokeType();
		resultArray.add(score);
		resultArray.add(p.getpoke());
		resultArray.add(p.getCaughtSize());
		resultArray.add(p.PokeType());
		resultArray.add(p.getMaxCP());
		
		for(int i=0; i< resultArray.size(); i++)
		System.out.println(resultArray.get(i));
		return resultArray;
	}

	public void setStart(int x, int y)
	{
		Start = new Position(x,y,"Begin");
	}
	
	public void setEnd(int x, int y)
	{
		End = new Position(x,y,"End");
	}
	
	
	public void setMap(Position q)
	{
		mapArray.add(q);
	}
	
	public void setPoke(Pokemon q)
	{
		PokeArray.add(q);
	}
	
	public void setStation(Station q)
	{
		StationArray.add(q);
	}
}
